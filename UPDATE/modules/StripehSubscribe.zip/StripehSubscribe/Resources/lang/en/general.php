<?php

return [

    'name'              => 'StripehSubscribe',
    'description'       => 'This is my awesome module',

];