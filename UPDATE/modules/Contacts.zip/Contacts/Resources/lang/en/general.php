<?php

return [

    'name'              => 'Contacts',
    'description'       => 'This is my awesome module',

];