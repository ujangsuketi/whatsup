<?php

namespace Modules\Contacts\Models;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    
    protected $table = 'countries';
    public $guarded = [];
}
