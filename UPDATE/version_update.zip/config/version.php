<?php

return
[
    'version' => '3.6.0',
];
